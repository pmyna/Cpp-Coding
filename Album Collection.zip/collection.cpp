#include "collection.hpp"
#include <string>
#include <vector>
#include <iostream>

using namespace std;

    Album::Album() //Default Constructor
    {
        interpret = "NA";
        titel = "NA";
        stil = "NA";
    }
    // Setters
    void Album::set_interpret(const string interpret){
        this->interpret = interpret;
    }
    void Album::set_titel(const string titel){
        this->titel = titel;
    }
    void Album::set_stil(const string stil){
        this->stil = stil;
    }
    //Getters
    string Album::get_interpret() const{
        return interpret;
    }
    string Album::get_titel() const{
        return titel;
    }
    string Album::get_stil() const{
        return stil;
    }

ostream & operator << (ostream&out, const Album&a){
    out << a.get_titel() << '\t' << a.get_interpret() << '\t' << a.get_stil() << '\n';
    return out;}
    
    void Collection::new_album(vector<Album>&collection){
        Album entry;
        string in,ti,st;
        cin.clear();
        cin.ignore();
        
        cout << "Geben Sie den Albumnamen ein: ";
            getline(cin, ti);
            entry.set_titel(ti);
        cout << "Geben Sie den Interpreten ein: ";
            getline(cin, in);
            entry.set_interpret(in);
        cout << "Geben Sie die Stilrichtung ein: ";
            getline(cin,st);
            entry.set_stil(st);
        cout << "Neues Album angelegt!\n\n";
        
       collection.push_back(entry);
    }
    
    void Collection::change_album(vector<Album>&collection){
        int x{0}, y;
        char choice;
        string new_title, new_interpret, new_stil;
        
        cout << "Welches Album soll bearbeitet werden?\n";
        cout << "[#]\t[Name]\t[Interpret]\t[Stilrichtung]\n";
        do{
            for(auto i{0}; i < collection.size(); i++){
                cout << "[" << x << "]" << '\t';
                cout << collection.at(i);
                x++;}
        }while (x < collection.size());
        
        cin >> y;
        cout << "Möchten Sie [A]lbumname, [I]nterpret oder [S]tilrichtung bearbeiten? ";
        cin >> choice;
            if (choice == 'A' || choice == 'a'){
                cin.clear();
                cin.ignore();
                cout << "Neuer Albumname: ";
                getline(cin, new_title);
                collection.at(y).set_titel(new_title);}
            if (choice == 'I' || choice == 'i'){
                cin.clear();
                cin.ignore();
                cout << "Neuer Interpret: ";
                getline(cin, new_interpret);
                collection.at(y).set_interpret(new_interpret);}
            if (choice == 'S' || choice == 's'){
                cin.clear();
                cin.ignore();
                cout << "Neue Stilrichtung: ";
                getline(cin, new_stil);
                collection.at(y).set_stil(new_stil);}
        cout << "Album bearbeitet!\n\n";
        }
    
    void Collection::delete_album(vector<Album>&collection){
        int x{0}, y;
        cout << "Welches Album soll gelöscht werden?\n\n";
        cout << "[#]\t[Name]\t[Interpret]\t[Stilrichtung]\n";
        do{
            for(auto i{0}; i < collection.size(); i++){
                cout << "[" << x << "]" << '\t';
                cout << collection.at(i);
                x++;}
        }while (x < collection.size());
        cout << '\n';
        cin >> y;
        collection.erase(collection.begin()+y);
        cout << "Album gelöscht!\n\n";
    }
    void Collection::search_album(vector<Album>&collection){
        char choice;
        string interpret, titel, stil;
        
        cout << "Suchen Sie nach [A]lbumname, [I]nterpret oder [S]tilrichtung? ";
        cin >> choice;
        if (choice == 'I' || choice == 'i'){
            cout << "Suche nach Interpret: ";
            cin >> interpret;
            cout << "\n[Name]\t[Interpret]\t[Stilrichtung]\n";
            for(auto i{0}; i < collection.size(); i++)
            if (interpret == collection.at(i).get_interpret())
                cout << collection.at(i) << "\n";
            }
        if (choice == 'a' || choice == 'A'){
            cout << "Suche nach Albumname: ";
            cin >> titel;
            cout << "\n[Name]\t[Interpret]\t[Stilrichtung]\n";
            for(auto i{0}; i < collection.size(); i++)
            if (titel == collection.at(i).get_titel())
                cout << collection.at(i) << "\n";
        }
        if (choice == 's' || choice == 'S'){
            cout << "Suche nach Stilrichtung: ";
            cin >> stil;
            cout << "\n[Name]\t[Interpret]\t[Stilrichtung]\n";
            for(auto i{0}; i < collection.size(); i++)
            if (stil == collection.at(i).get_stil())
                cout << collection.at(i) << "\n";
        }
    }

